##### Article code and Figure 1.
library(data.table)
library(ggplot2)

### R code from vignette source 'article.Rnw'

###################################################
### code chunk number 1: preliminaries
###################################################
options(prompt = "R> ", continue = "+  ", width = 80, useFancyQuotes = FALSE)
library("MASS")


###################################################
### code chunk number 2: article.Rnw:610-611
###################################################
ex6_df <- data.frame(value = c(1, -7, 8, 10, 2, 4))


###################################################
### code chunk number 3: article.Rnw:614-618
###################################################
ex6_binsegRcpp <- binsegRcpp::binseg(
  "mean_norm", ex6_df$value, max.segments = 4)
ex6_binsegRcpp$splits[, .(segments, end, before.mean, after.mean,
  invalidates.index, invalidates.after)]


###################################################
### code chunk number 4: article.Rnw:642-643
###################################################
(ex6_segments <- coef(ex6_binsegRcpp, 2:4))


###################################################
### code chunk number 5: ex6
###################################################
library(ggplot2)
ex6_df$position <- 1:nrow(ex6_df)
png("figure-1.png")
ggplot() + geom_point(aes(position, value), data = ex6_df) +
  geom_segment(aes(start.pos, y = mean, xend = end.pos, yend = mean),
    color = "green", data = ex6_segments) +
  geom_vline(aes(xintercept = start.pos), color="green",
    linetype = "dashed", data = ex6_segments[1 < start]) +
  facet_grid(segments ~ ., labeller = label_both)
dev.off()

###################################################
### code chunk number 6: article.Rnw:675-678
###################################################
ex6_changepoint <- changepoint::cpt.mean(ex6_df$value,
  method = "BinSeg", Q = 3, penalty = "Manual", pen.value = 0)
changepoint::cpts.full(ex6_changepoint)


###################################################
### code chunk number 7: article.Rnw:706-707
###################################################
changepoint::param.est(ex6_changepoint)


###################################################
### code chunk number 8: article.Rnw:722-724
###################################################
ex6_wbs <- wbs::sbs(ex6_df$value)
data.table::data.table(ex6_wbs$res)[order(-min.th)]


###################################################
### code chunk number 9: article.Rnw:741-743
###################################################
set.seed(8)
two_changes <- c(rnorm(7, 1), rnorm(10, 3), rnorm(5, 0))


###################################################
### code chunk number 10: article.Rnw:746-747
###################################################
(is.validation.vec <- rep(c(TRUE, FALSE), l=length(two_changes)))


###################################################
### code chunk number 11: article.Rnw:750-753
###################################################
valid_fit <- binsegRcpp::binseg("mean_norm", two_changes, 
  is.validation.vec = is.validation.vec)
valid_fit


##### Figure 2
library(data.table)
data(neuroblastoma,package="neuroblastoma")
nb.profiles <- data.table(neuroblastoma[["profiles"]])
one.pid.chr <- nb.profiles[profile.id==2 & chromosome==2]
one.pid.chr[, data.i := .I]
data.vec <- one.pid.chr$logratio
N.data <- length(data.vec)
cum.data.vec <- cumsum(c(0,data.vec))
max.segs <- 5
max.changes <- max.segs-1
binseg.fit <- binsegRcpp::binseg_normal(data.vec, max.segs)
cpt.fit <- changepoint::cpt.mean(data.vec, method="BinSeg", Q=max.changes)
loss.dt.list <- list()
seg.dt.list <- list()
for(n.changes in 1:max.changes){
  n.segs <- n.changes+1L
  end.list <- list(
    changepoint=c(N.data, cpt.fit@cpts.full[n.changes,]),
    binsegRcpp=coef(binseg.fit, n.segs)$end
  )
  for(package in names(end.list)){
    end <- sort(end.list[[package]])
    seg.size <- diff(c(0,end))
    seg.mean <- (cum.data.vec[end+1]-cum.data.vec[end-seg.size+1])/seg.size
    data.mean <- rep(seg.mean, seg.size)
    seg.dt.list[[paste(n.changes, package)]] <- data.table(
      n.changes,
      package,
      start=end-seg.size+1L,
      end,
      mean=seg.mean)
    loss.dt.list[[paste(n.changes, package)]] <- data.table(
      n.changes, package, total.square.loss=sum((data.mean-data.vec)^2))
  }
}
loss.dt <- do.call(rbind, loss.dt.list)
dcast(loss.dt, package ~ n.changes, value.var="total.square.loss")
seg.dt <- do.call(rbind, seg.dt.list)
loss.y <- c(
  binsegRcpp=6,
  changepoint=4)
library(ggplot2)
gg <- ggplot()+
  theme_bw()+
  scale_color_manual(values=c(binsegRcpp="red", changepoint="black"))+
  scale_size_manual(values=c(binsegRcpp=1, changepoint=2))+
  geom_text(aes(
    40, loss.y[package], color=package,
    label=sprintf(
      "%s (%s) loss= %.2f",
      package,
      ifelse(package=="binsegRcpp", "correct", "incorrect"),
      total.square.loss)),
    hjust=1,
    data=loss.dt)+
  scale_x_continuous(
    "Position/index in data sequence",
    breaks=seq(0,1000,by=2),
    limits=c(0, nrow(one.pid.chr)+1))+
  scale_y_continuous(
    "DNA copy number logratio to segment")+
  geom_segment(aes(
    start-0.5, mean,
    size=package,
    color=package,
    xend=end+0.5, yend=mean),
    data=seg.dt)+
  geom_vline(aes(
    xintercept=start-0.5,
    size=package,
    color=package),
    linetype="dashed",
    data=seg.dt[1 < start])+
  facet_grid(n.changes ~ ., labeller=label_both)+
  geom_point(aes(
    data.i, logratio),
    color="grey50",
    shape=21,
    fill="white",
    data=one.pid.chr)+
  coord_cartesian(
    expand=FALSE,
    ylim=c(-1, 7),
    xlim=c(19,71))
png("figure-2.png", width=10, height=5, units="in", res=200)
print(gg)
dev.off()

##### Figure 3
set.seed(8)
two_changes <- c(rnorm(7, 1), rnorm(10, 3), rnorm(5, 0))
(is.validation.vec <- rep(c(TRUE, FALSE), l=length(two_changes)))
valid_fit <- binsegRcpp::binseg("mean_norm", two_changes, 
  is.validation.vec = is.validation.vec)
valid_fit
(vsegs <- coef(valid_fit, 3L))
vdata <- data.table::data.table(value = two_changes,
 position = seq_along(two_changes), set = ifelse(
   is.validation.vec, "validation", "subtrain"))
valid_join <- vsegs[vdata, .(position, mean, value, set, segments), on=.(start.pos<position, end.pos>position)]
valid_join[, .(loss=sum((mean-value)^2)), by=.(set, segments)]
valid_fit$splits[3, .(segments, loss, validation.loss)]
library(ggplot2)
gg <- ggplot() +
  theme_bw()+
  scale_fill_manual(values = c(subtrain = "black", validation = "white")) +
  scale_color_manual(values = c("validation loss" = "violet", "subtrain mean" = "green")) +
  geom_point(aes(position, value, fill = set), shape = 21, data = vdata) +
  geom_segment(aes(
    start.pos, mean, xend = end.pos, yend = mean, color=line),
    data = data.frame(vsegs, line="subtrain mean")) + 
    scale_x_continuous(breaks=1:22)+
  geom_segment(aes(
    position, mean,
    color=line,
    xend=position, yend=value),
    size=1,
    data=data.frame(valid_join[set=="validation"], line="validation loss"))+
  theme(panel.grid.minor=element_blank())
pdf("figure-3.pdf", height=2.1)
print(gg)
dev.off()

##### Figure 4
(objs <- load("figure-heap-data.RData"))
library(atime)
atime_list$measurements[, expr.name := sub("container=", "", expr.name)]
fun_list <- atime:::references_funs[c("N","N \\log N", "N^2", "N^3")]
myexp <- 1.4
fun_list[[paste0("N^",myexp)]] <- function(N)myexp * log10(N)
ref_list <- atime::references_best(atime_list, fun_list)
ref_list$plot.references <- ref_list$references[(
  fun.name %in% c("N","N^2") & unit=="kilobytes"
)|(unit=="seconds" & ( (
  grepl("binsegRcpp", expr.name) & fun.name %in% c("N log N", "N^2")
)|(
  expr.name=="ruptures" & !fun.name%in%c("N^3","N")
)|(
  expr.name=="changepoint" & fun.name%in%c("N^2","N^3")
)))]
##ref_list$measurements <- ref_list
png("figure-4.png",width=6,height=3.5,units="in",res=200)
plot_algos <- function(regex){
  regex_list <- ref_list
  regex_list$measurements <- ref_list$measurements[grepl(regex,expr.name)]
  regex_list$plot.references <- ref_list$plot.references[grepl(regex,expr.name)]
  plot(regex_list)+
    geom_blank(aes(
      N, empirical),
      data=ref_list$measurements[,.(N=1000,empirical,unit)])+
    scale_x_log10(
      breaks=10^seq(1,7,by=1))+
    theme(
      axis.text.x=element_text(angle=30,hjust=1))
}
plot_algos("list|multiset")
dev.off()

##### Figure 5
png("figure-5.png",width=6,height=3.5,units="in",res=200)
plot_algos("change|rupt")
dev.off()

##### Figure 6
pred_list <- predict(ref_list)
png("figure-6.png",width=8,height=3,units="in",res=200)
pkg.colors <- c(
  changepoint="#E41A1C",
  ruptures="#377EB8",
  "binsegRcpp\nmultiset"="black",
  "binsegRcpp\npriority_queue"="grey30",
  "binsegRcpp\nlist"="grey50")
plot(pred_list)+
  facet_null()+
  scale_y_log10(
    "Computation time (seconds, log scale)",
    breaks=10^seq(-3,1),
    limits=c(NA,200))+
  scale_x_log10(
    "N = number of data to segment (max segments = N/2)",
    breaks=10^seq(1,7),
    limits=c(NA, 1e8))+
  scale_color_manual(values=pkg.colors)+
  scale_fill_manual(values=pkg.colors)
dev.off()

##### Figure 7
pkg.colors <- c(
  "changepoint\narray"="#E41A1C",
  "ruptures\nLRU cache"="#377EB8",
  "ruptures\nl2"="#377EB8",
  "ruptures\ncumsum"="#377EB8",
  "blockcpd\nheap"="#984EA3", 
  "fpop::multiBinSeg\nheap"="#FF7F00", 
  "wbs::sbs\nrecursion"="#A65628",
  "binsegRcpp\nmultiset"="black",
  "binsegRcpp\nlist"="grey50")
disp.pkg <- c(
  blockcpd="blockcpd.heap",
  changepoint="changepoint.array",
  ruptures="ruptures.LRU cache",
  "wbs::sbs"="wbs::sbs.recursion",
  "fpop::multiBinSeg"="fpop::multiBinSeg.heap")
timing.stats <- data.table::fread("figure-timings-data.csv")
timing.stats[, new.pkg := ifelse(
  package %in% names(disp.pkg), disp.pkg[package], package)]
timing.stats[, Package := sub("[.]", "\n", new.pkg, perl=TRUE)]
##timing.stats[, Package := sub("[.]|(?<=fpop)::", "\n", package, perl=TRUE)]
(total.minutes <- timing.stats[, sum(seconds_median*seconds_timings) / 60])
timing.stats[, min.loss := min(loss), by=.(case,N.data)]
timing.stats[loss==min.loss, .(N.data, max.segs, case, Package, loss, min.loss)]
timing.stats[loss>min.loss, .(N.data, max.segs, case, Package, loss, min.loss)]
ref.dt <- rbind(
  data.table(seconds=1, unit="1 second"),
  data.table(seconds=60, unit="1 minute"))
gg <- ggplot()+
  ggtitle("Normal change in mean with constant variance (square loss)")+
  scale_color_manual(values=pkg.colors)+
  scale_fill_manual(values=pkg.colors)+
  theme_bw()+
  theme(
    legend.position="none",
    panel.spacing=grid::unit(0, "lines"))+
  facet_grid(. ~ case, labeller=label_both)+
  geom_hline(aes(
    yintercept=seconds),
    data=ref.dt,
    color="grey")+
  geom_text(aes(
    10, seconds, label=unit),
    data=ref.dt,
    size=3,
    hjust=0,
    vjust=1.1,
    color="grey50")+
  directlabels::geom_dl(aes(
    N.data, seconds_median, color=Package, label=Package),
    data=timing.stats,
    method=list(cex=0.6, "last.polygons"))+
  geom_ribbon(aes(
    N.data, ymin=seconds_min, ymax=seconds_max, fill=Package),
    alpha=0.5,
    data=timing.stats)+
  geom_line(aes(
    N.data, seconds_median, color=Package),
    data=timing.stats)+
  scale_x_log10(
    "Number of data points to segment (log scale)",
    breaks=10^seq(1, 6, by=1))+
  coord_cartesian(
    expand=FALSE,
    ylim=c(1e-4, 1e3),
    xlim=c(8, 9e7))+
  scale_y_log10(
    "Computation time (seconds, log scale)\nMedian line and min/max band over 5 timings",
    breaks=10^seq(-10,10))
png("figure-7.png", width=9, height=3.5, units="in", res=200)
print(gg)
dev.off()

##### Figure 8
timing.stats <- data.table::fread(
"figure-timings-meanvar_norm-data.csv"
)[N.data<2^19]
timing.stats[, new.pkg := ifelse(
  package %in% names(disp.pkg), disp.pkg[package], package)]
timing.stats[, Package := sub("[.]", "\n", new.pkg, perl=TRUE)]
(total.minutes <- timing.stats[, sum(seconds_median*seconds_timings) / 60])
timing.stats[, min.loss := min(loss), by=.(case,N.data)]
timing.stats[loss==min.loss, .(N.data, max.segs, case, Package, loss, min.loss)]
timing.stats[loss>min.loss, .(N.data, max.segs, case, Package, loss, min.loss)]
ref.dt <- rbind(
  data.table(seconds=1, unit="1 second"),
  data.table(seconds=60, unit="1 minute"))
gg <- ggplot()+
  scale_color_manual(values=pkg.colors)+
  scale_fill_manual(values=pkg.colors)+
  ggtitle("Normal change in mean and variance")+
  theme_bw()+
  theme(
    legend.position="none",
    panel.spacing=grid::unit(0, "lines"))+
  facet_grid(. ~ case, labeller=label_both)+
  geom_hline(aes(
    yintercept=seconds),
    data=ref.dt,
    color="grey")+
  geom_text(aes(
    10, seconds, label=unit),
    data=ref.dt,
    size=3,
    hjust=0,
    vjust=1.1,
    color="grey50")+
  directlabels::geom_dl(aes(
    N.data, seconds_median, color=Package, label=Package),
    data=timing.stats,
    method=list(cex=0.6, "last.polygons"))+
  geom_ribbon(aes(
    N.data, ymin=seconds_min, ymax=seconds_max, fill=Package),
    alpha=0.5,
    data=timing.stats)+
  geom_line(aes(
    N.data, seconds_median, color=Package),
    data=timing.stats)+
  scale_x_log10(
    "Number of data points to segment (log scale)",
    breaks=10^seq(1, 6, by=1))+
  coord_cartesian(
    expand=FALSE,
    ylim=c(1e-4, 1e3),
    xlim=c(8, 5e6))+
  scale_y_log10(
    "Computation time (seconds, log scale)\nMedian line and min/max band over 5 timings",
    breaks=10^seq(-10,10))
png("figure-8.png", width=9, height=3.5, units="in", res=200)
print(gg)
dev.off()

##### Figure 9
timing.stats <- data.table::fread("figure-timings-poisson-data.csv")
timing.stats[, new.pkg := ifelse(
  package %in% names(disp.pkg), disp.pkg[package], package)]
timing.stats[, Package := sub("[.]", "\n", new.pkg, perl=TRUE)]
(total.minutes <- timing.stats[, sum(seconds_median*seconds_timings) / 60])
timing.stats[, min.loss := min(loss), by=.(case,N.data)]
timing.stats[loss==min.loss, .(N.data, max.segs, case, Package, loss, min.loss)]
timing.stats[loss>min.loss, .(N.data, max.segs, case, Package, loss, min.loss)]
ref.dt <- rbind(
  data.table(seconds=1, unit="1 second"),
  data.table(seconds=60, unit="1 minute"))
gg <- ggplot()+
  scale_color_manual(values=pkg.colors)+
  scale_fill_manual(values=pkg.colors)+
  ggtitle("Poisson loss")+
  theme_bw()+
  theme(
    legend.position="none",
    panel.spacing=grid::unit(0, "lines"))+
  facet_grid(. ~ case, labeller=label_both)+
  geom_hline(aes(
    yintercept=seconds),
    data=ref.dt,
    color="grey")+
  geom_text(aes(
    10, seconds, label=unit),
    data=ref.dt,
    size=3,
    hjust=0,
    vjust=1.1,
    color="grey50")+
  directlabels::geom_dl(aes(
    N.data, seconds_median, color=Package, label=Package),
    data=timing.stats,
    method=list(cex=0.6, "last.polygons"))+
  geom_ribbon(aes(
    N.data, ymin=seconds_min, ymax=seconds_max, fill=Package),
    alpha=0.5,
    data=timing.stats)+
  geom_line(aes(
    N.data, seconds_median, color=Package),
    data=timing.stats)+
  scale_x_log10(
    "Number of data points to segment (log scale)",
    breaks=10^seq(1, 6, by=1))+
  coord_cartesian(
    expand=FALSE,
    ylim=c(1e-4, 1e3),
    xlim=c(8, 3e7))+
  scale_y_log10(
    "Computation time (seconds, log scale)\nMedian line and min/max band over 5 timings",
    breaks=10^seq(-10,10))
png("figure-9.png", width=9, height=3.5, units="in", res=200)
print(gg)
dev.off()

##### Figure 10
timing.stats <- data.table::fread("figure-timings-laplace-data.csv")
timing.stats[, new.pkg := ifelse(
  package %in% names(disp.pkg), disp.pkg[package], package)]
timing.stats[, Package := sub("[.]", "\n", new.pkg, perl=TRUE)]
(total.minutes <- timing.stats[, sum(seconds_median*seconds_timings) / 60])
timing.stats[, min.loss := min(loss), by=.(case,N.data)]
timing.stats[loss==min.loss, .(N.data, max.segs, case, Package, loss, min.loss)]
timing.stats[loss>min.loss, .(N.data, max.segs, case, Package, loss, min.loss)]
ref.dt <- rbind(
  data.table(seconds=1, unit="1 second"),
  data.table(seconds=60, unit="1 minute"))
gg <- ggplot()+
  scale_color_manual(values=pkg.colors)+
  scale_fill_manual(values=pkg.colors)+
  ggtitle("L1 loss")+
  theme_bw()+
  theme(
    legend.position="none",
    panel.spacing=grid::unit(0, "lines"))+
  facet_grid(. ~ case, labeller=label_both)+
  geom_hline(aes(
    yintercept=seconds),
    data=ref.dt,
    color="grey")+
  geom_text(aes(
    10, seconds, label=unit),
    data=ref.dt,
    size=3,
    hjust=0,
    vjust=1.1,
    color="grey50")+
  directlabels::geom_dl(aes(
    N.data, seconds_median, color=Package, label=Package),
    data=timing.stats,
    method=list(cex=0.6, "last.polygons"))+
  geom_ribbon(aes(
    N.data, ymin=seconds_min, ymax=seconds_max, fill=Package),
    alpha=0.5,
    data=timing.stats)+
  geom_line(aes(
    N.data, seconds_median, color=Package),
    data=timing.stats)+
  scale_x_log10(
    "Number of data points to segment (log scale)",
    breaks=10^seq(1, 6, by=1))+
  coord_cartesian(
    expand=FALSE,
    ylim=c(1e-4, 1e3),
    xlim=c(8, 3e7))+
  scale_y_log10(
    "Computation time (seconds, log scale)\nMedian line and min/max band over 5 timings",
    breaks=10^seq(-10,10))
png("figure-10.png", width=9, height=3.5, units="in", res=200)
print(gg)
dev.off()

##### Figure 11
timings.csv.vec <- c(
  "normal\nmean"="figure-timings-data.csv", 
  "Laplace\nmedian"="figure-timings-laplace-data.csv", 
  "normal\nmean+\nvariance"="figure-timings-meanvar_norm-data.csv", 
  poisson="figure-timings-poisson-data.csv")
timings.dt.list <- list()
for(distribution in names(timings.csv.vec)){
  timings.csv <- timings.csv.vec[[distribution]]
  timings.dt.list[[distribution]] <- data.table(
    distribution, 
    data.table::fread(timings.csv)[
      grepl("binsegRcpp", package),
      data.table(
        case, 
        seconds_min, seconds_max, seconds_median,
        package, N.data)])
}
(timings.dt <- do.call(rbind, timings.dt.list))
timings.dt[, container := sub("binsegRcpp.", "", package)]
only.multiset <- timings.dt[container=="multiset"]
ref.dt <- rbind(
  data.table(seconds=1, unit="1 second"),
  data.table(seconds=60, unit="1 minute"))
gg <- ggplot()+
  ggtitle("Comparing distributions using binsegRcpp multiset")+
  theme_bw()+
  theme(panel.spacing=grid::unit(0, "lines"))+
  geom_hline(aes(
    yintercept=seconds),
    data=ref.dt,
    color="grey")+
  geom_text(aes(
    10, seconds, label=unit),
    data=ref.dt,
    size=3,
    hjust=0,
    vjust=1.1,
    color="grey50")+
  facet_grid(. ~ case, labeller=label_both)+
  geom_ribbon(aes(
    N.data, ymin=seconds_min, ymax=seconds_max, fill=distribution),
    data=only.multiset,
    alpha=0.5)+
  geom_line(aes(
    N.data, seconds_median, color=distribution),
    data = only.multiset)+
  scale_x_log10(
    "Number of data points to segment (log scale)",
    breaks=10^seq(1, 6, by=1))+
  coord_cartesian(
    expand=FALSE,
    ylim=c(1e-4, 1e3),
    xlim=c(8, 9e6))+
  scale_y_log10(
    "Computation time (seconds, log scale)\nMedian line and min/max band over 5 timings",
    breaks=10^seq(-10,10))
dl <- directlabels::direct.label(gg, list(cex=0.6, "right.polygons"))
png("figure-11.png", width=9, height=3.5, units="in", res=200)
print(dl)
dev.off()
