## Reproducing the figures

To re-make the figures in the paper, please run

```sh
R --vanilla < figures.R
```

If you get errors about missing packages, try 

```r
install.packages(c("neuroblastoma","data.table","ggplot2","changepoint","wbs","atime","directlabels"))
```

## Reproducing the data files

This folder contains CSV and RData files with timings that took a long
time to compute! To re-do these timings on your computer, it will
probably take several days, and the code in "R timing code" files
linked from [the GitHub
README](https://github.com/tdhock/binseg-model-selection?tab=readme-ov-file#paper-comparing-binsegrcpp-with-other-implementations-of-binary-segmentation-for-change-point-detection).
